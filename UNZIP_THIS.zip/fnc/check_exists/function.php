<?php
function execute_check_exists($params) {
    $path = $params['path'] ?? '';
    
    if (empty($path)) {
        return "❌ Chemin manquant";
    }
    
    $full_path = __DIR__ . '/../../' . ltrim($path, '/');
    
    if (file_exists($full_path)) {
        $type = is_dir($full_path) ? 'dossier' : 'fichier';
        return "✅ $type existe: $path";
    } else {
        return "❌ N'existe pas: $path";
    }
}
?>