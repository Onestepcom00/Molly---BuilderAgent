<?php
function execute_create_directory($params) {
    $dir_path = $params['dir_path'] ?? '';
    
    if (empty($dir_path)) {
        return "❌ Chemin de dossier manquant";
    }
    
    // Détermine le chemin complet
    if (strpos($dir_path, 'core/') === 0) {
        $full_path = __DIR__ . '/../../' . ltrim($dir_path, '/');
    } else {
        $full_path = __DIR__ . '/../../tmp/' . ltrim($dir_path, '/');
    }
    
    if (!mkdir($full_path, 0755, true)) {
        return "❌ Erreur lors de la création du dossier: $dir_path";
    }
    
    return "✅ Dossier créé: $dir_path";
}
?>