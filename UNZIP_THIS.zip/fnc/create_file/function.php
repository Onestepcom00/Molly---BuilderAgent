<?php
function execute_create_file($params) {
    $file_path = $params['file_path'] ?? '';
    $content = $params['content'] ?? '';
    
    if (empty($file_path)) {
        return "❌ Chemin de fichier manquant";
    }
    
    // Détermine le chemin complet
    if (strpos($file_path, 'core/routes/') === 0) {
        $full_path = __DIR__ . '/../../' . ltrim($file_path, '/');
    } else {
        $full_path = __DIR__ . '/../../tmp/' . ltrim($file_path, '/');
    }
    
    // Sécurise le chemin
    $base_dir = __DIR__ . '/../..';
    if (strpos(realpath(dirname($full_path)), realpath($base_dir)) !== 0) {
        return "❌ Chemin de fichier non autorisé";
    }
    
    // Crée le dossier parent si nécessaire
    $dir = dirname($full_path);
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
    
    // Crée le fichier avec le contenu
    if (file_put_contents($full_path, $content) !== false) {
        return "✅ Fichier créé: $file_path";
    } else {
        return "❌ Erreur lors de la création du fichier: $file_path";
    }
}
?>