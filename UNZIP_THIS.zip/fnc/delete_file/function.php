<?php
function execute_delete_file($params) {
    $file_path = $params['file_path'] ?? '';
    
    if (empty($file_path)) {
        return "❌ Chemin de fichier manquant";
    }
    
    $full_path = __DIR__ . '/../../' . ltrim($file_path, '/');
    
    if (!file_exists($full_path)) {
        return "❌ Fichier introuvable: $file_path";
    }
    
    if (!unlink($full_path)) {
        return "❌ Erreur lors de la suppression: $file_path";
    }
    
    return "✅ Fichier supprimé: $file_path";
}
?>