<?php
function execute_read_file($params) {
    $file_path = $params['file_path'] ?? '';
    
    if (empty($file_path)) {
        return "❌ Chemin de fichier manquant";
    }
    
    $full_path = __DIR__ . '/../../' . ltrim($file_path, '/');
    
    if (!file_exists($full_path)) {
        return "❌ Fichier introuvable: $file_path";
    }
    
    $content = file_get_contents($full_path);
    
    if ($content === false) {
        return "❌ Erreur de lecture: $file_path";
    }
    
    return "✅ Contenu de $file_path:\n" . $content;
}
?>