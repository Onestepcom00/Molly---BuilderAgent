<?php
function execute_write_file($params) {
    $file_path = $params['file_path'] ?? '';
    $content = $params['content'] ?? '';
    
    if (empty($file_path)) {
        return "❌ Chemin de fichier manquant";
    }
    
    $full_path = __DIR__ . '/../../' . ltrim($file_path, '/');
    
    if (!file_exists($full_path)) {
        return "❌ Fichier introuvable: $file_path";
    }
    
    if (file_put_contents($full_path, $content, LOCK_EX) !== false) {
        return "✅ Contenu écrit dans: $file_path";
    } else {
        return "❌ Erreur d'écriture dans: $file_path";
    }
}
?>