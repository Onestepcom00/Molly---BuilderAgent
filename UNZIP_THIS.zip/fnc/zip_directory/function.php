<?php
function execute_zip_directory($params) {
    $source_dir = $params['source_dir'] ?? '';
    $output_zip = $params['output_zip'] ?? '';
    
    if (empty($source_dir)) {
        return "❌ Chemin du dossier source manquant";
    }
    
    // Vérifie que le dossier source existe
    if (!file_exists($source_dir) || !is_dir($source_dir)) {
        return "❌ Le dossier source n'existe pas : $source_dir";
    }
    
    // Détermine le chemin de sortie si non spécifié
    if (empty($output_zip)) {
        $output_zip = $source_dir . '.zip';
    }
    
    // Sécurise les chemins
    $base_dir = realpath(__DIR__ . '/../..');
    $full_source = realpath($source_dir);
    
    if ($full_source === false) {
        return "❌ Chemin source invalide : $source_dir";
    }
    
    // Vérifie que les chemins sont autorisés
    if (strpos($full_source, $base_dir) !== 0) {
        return "❌ Chemin source non autorisé : $source_dir";
    }
    
    $full_output = $base_dir . '/' . ltrim($output_zip, '/');
    $output_dir = dirname($full_output);
    
    if (strpos($output_dir, $base_dir) !== 0) {
        return "❌ Chemin de sortie non autorisé : $output_zip";
    }
    
    // Crée le dossier parent du fichier ZIP si nécessaire
    if (!file_exists($output_dir)) {
        if (!mkdir($output_dir, 0755, true)) {
            return "❌ Impossible de créer le dossier de sortie : " . dirname($output_zip);
        }
    }
    
    // Vérifie si l'extension Zip est disponible
    if (!class_exists('ZipArchive')) {
        return "❌ L'extension Zip n'est pas disponible sur ce serveur";
    }
    
    try {
        // Crée l'archive ZIP
        $zip = new ZipArchive();
        $result = $zip->open($full_output, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        
        if ($result !== TRUE) {
            return "❌ Impossible de créer l'archive ZIP";
        }
        
        // Ajoute récursivement les fichiers au ZIP
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($full_source, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        $file_count = 0;
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $file_path = $file->getRealPath();
                $relative_path = substr($file_path, strlen($full_source) + 1);
                
                // Ajoute le fichier à l'archive
                if ($zip->addFile($file_path, $relative_path)) {
                    $file_count++;
                }
            }
        }
        
        $zip->close();
        
        if ($file_count > 0) {
            $zip_size = filesize($full_output);
            return "✅ Archive créée : $output_zip ($file_count fichiers, " . formatBytes($zip_size) . ")";
        } else {
            // Supprime le ZIP vide
            if (file_exists($full_output)) {
                unlink($full_output);
            }
            return "⚠️ Aucun fichier trouvé dans le dossier : $source_dir";
        }
        
    } catch (Exception $e) {
        // Log l'erreur complète pour le débogage
        error_log("ZIP Error: " . $e->getMessage());
        return "❌ Erreur lors de la création du ZIP";
    }
}

/**
 * Formate la taille en octets en format lisible
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['o', 'Ko', 'Mo', 'Go', 'To'];
    
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>